CREATE DATABASE  IF NOT EXISTS `TIME61` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `TIME61`;
-- MySQL dump 10.13  Distrib 5.6.13, for osx10.6 (i386)
--
-- Host: 127.0.0.1    Database: TIME61
-- ------------------------------------------------------
-- Server version	5.6.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `newsay`
--

DROP TABLE IF EXISTS `newsay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newsay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` int(11) NOT NULL,
  `content` varchar(140) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `imageURL` varchar(245) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newsay`
--

LOCK TABLES `newsay` WRITE;
/*!40000 ALTER TABLE `newsay` DISABLE KEYS */;
INSERT INTO `newsay` VALUES (1,1,'may name is andy','2014-03-05 10:52:10','http://time61/upload/painting/138716649400.jpg'),(2,2,'you are my sunshine','2014-03-05 10:52:10','http://time61/upload/painting/4_137232640200.jpg'),(3,3,'do do do do do ......','2014-03-05 10:52:10','http://time61/upload/painting/138268887100.jpg'),(4,4,'do you like my painting?','2014-03-05 10:52:10','http://time61/upload/painting/138242901900.jpg'),(5,5,'Someone stole a painting from the museum. ','2014-03-05 10:52:10','http://time61/upload/painting/138233440100.jpg'),(6,3,'He shows a great aptitude for painting.','2014-03-05 10:52:10','http://time61/upload/painting/138251082300.jpg'),(7,4,'He gave me a painting with his name subscribed.','2014-03-05 10:52:10','http://time61/upload/painting/138233463400.jpg'),(8,1,'He ran a nail into the wall to hang his painting.','2014-03-05 10:52:10','http://time61/upload/painting/138233359200.jpg'),(9,5,'You hear this from math to painting.','2014-03-05 10:52:10','http://time61/upload/painting/138233333800.jpg'),(10,3,'After I read your story, I took the painting down off my wall.','2014-03-05 10:52:10','http://time61/upload/painting/138208129400.jpg'),(11,1,'They speak to the deeper history of painting.','2014-03-05 10:52:10','http://time61/upload/painting/138208127500.jpg'),(12,4,'But the three of them then go to another hotel room where a fourth guy actually has the painting.','2014-03-05 10:52:10','http://time61/upload/painting/138199069300.jpg'),(13,2,'He reproduced the painting by photography','2014-03-05 10:52:10','http://time61/upload/painting/138199053400.jpg'),(14,5,'A painting should be looked at alone, or with one or two others.','2014-03-05 10:52:10','http://time61/upload/painting/138190231400.jpg'),(15,3,'And do the painting and provenance tell us more about his sexuality, and possibly about the person to whom the sonnets are addressed?','2014-03-05 10:52:10','http://time61/upload/painting/138190243200.jpg'),(16,1,'His hobby is painting abstract images of the brain cells he studies in his lab.','2014-03-05 10:52:10','http://time61/upload/painting/138190230000.jpg'),(17,4,'But I am more interested in painting now.','2014-03-05 10:52:10','http://time61/upload/painting/138190198700.jpg'),(18,2,'Only the painting of the son would be auctioned.','2014-03-05 10:52:10','http://time61/upload/painting/138181707400.jpg'),(19,5,'And so, he gave this painting to the National Gallery.','2014-03-05 10:52:10','http://time61/upload/painting/138181624200.jpg'),(20,3,'I love painting.','2014-03-05 10:52:10','http://time61/upload/painting/138172204700.jpg'),(21,7,'FFFFFFFFFFFFFFFFFFFF','2014-03-05 10:52:10','http://time61/upload/painting/138172209200.jpg'),(22,7,'dkhahwuhdoadwoaihcfabclDBCS','2014-03-05 10:52:10','http://time61/upload/painting/138172211500.jpg');
/*!40000 ALTER TABLE `newsay` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-03-06  9:41:39
