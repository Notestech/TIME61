CREATE DATABASE  IF NOT EXISTS `TIME61` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `TIME61`;
-- MySQL dump 10.13  Distrib 5.6.13, for osx10.6 (i386)
--
-- Host: 127.0.0.1    Database: TIME61
-- ------------------------------------------------------
-- Server version	5.6.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `PaintingInfo`
--

DROP TABLE IF EXISTS `PaintingInfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PaintingInfo` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PaintingURL` varchar(200) NOT NULL,
  `PaintingTitle` varchar(100) NOT NULL,
  `PaintingOwner` int(11) NOT NULL,
  `PaintingShare` int(11) NOT NULL DEFAULT '0',
  `PaintingComment` int(11) NOT NULL DEFAULT '0',
  `PaintingLove` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Id_UNIQUE` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PaintingInfo`
--

LOCK TABLES `PaintingInfo` WRITE;
/*!40000 ALTER TABLE `PaintingInfo` DISABLE KEYS */;
INSERT INTO `PaintingInfo` VALUES (1,'http://time61/upload/painting/painting_0002.png','Cat',4,0,0,0),(2,'http://time61/upload/painting/painting_0001.png','Magic mushroom',1,0,0,0),(3,'http://time61/upload/painting/painting_0002.png','Cat',4,0,0,0),(4,'http://time61/upload/painting/painting_0003.png','courtyard',1,0,0,0),(5,'http://time61/upload/painting/painting_0004.png','Sun and stars',1,0,0,0),(6,'http://time61/upload/painting/painting_0005.png','My mom with me',3,0,0,0),(7,'http://time61/upload/painting/painting_0006.png','Morning Exercise',1,0,0,0),(8,'http://time61/upload/painting/painting_0007.png','Space Ship',2,0,0,0),(9,'http://time61/upload/painting/painting_0008.png','Animal World',1,0,0,0),(10,'http://time61/upload/painting/painting_0009.png','Sea',2,0,0,0),(11,'http://time61/upload/painting/painting_0010.png','Water Mountain',4,0,0,0),(12,'http://time61/upload/painting/painting_0011.png','Bird',3,0,0,0),(13,'http://time61/upload/painting/painting_0012.png','Yello Xiong',3,0,0,0),(14,'http://time61/upload/painting/painting_0013.png','Love Bee',3,0,0,0),(15,'http://time61/upload/painting/painting_0014.png','Moring Sun',4,0,0,0),(16,'http://time61/upload/painting/painting_0015.png','tiger',2,0,0,0),(17,'http://time61/upload/painting/painting_0016.png','life',1,0,0,0),(18,'http://time61/upload/painting/painting_0017.png','xi yang yang',1,0,0,0),(19,'http://time61/upload/painting/painting_0018.png','cattle',2,0,0,0),(20,'http://time61/upload/painting/painting_0019.png','swimming',1,0,0,0),(21,'http://time61/upload/paintig/painting_0020.png','peacock',2,0,0,0);
/*!40000 ALTER TABLE `PaintingInfo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-03-06  9:41:39
